import json
from app.services.llm.provider_router import (
    provider_router
)

VALID_INTENTS = [
    "product_query", 
    "add_to_cart", 
    "view_cart", 
    "place_order", 
    "order_status", 
    "order_history", 
    "greeting", 
    "explain", 
    "fallback"
]

INTENT_PROMPT = """
Analyze the user message and extract intent, entities and normalize it.
Translate slang (e.g. "pacha sare cheap ah", "lit") into standard English as `normalized_query`.
You MUST classify the message into one or more of the following finite intents:
- "product_query": user is searching for a product, checking price, or exploring catalog.
- "add_to_cart": user explicitly wants to add an item to their cart (e.g. "add to cart", "add this").
- "view_cart": user wants to see what is currently in their shopping cart.
- "place_order": user wants to checkout and purchase the items in the cart.
- "order_status": user is asking for the tracking or current status of an existing order.
- "order_history": user wants to view their past orders.
- "greeting": conversational opening (e.g. "hi", "hello").
- "explain": user is asking for qualitative information, FAQ details, or explanation (e.g. "quality").
- "fallback": default catch-all if the user request is completely unclear or outside the scope of commerce.

Return a strict JSON format with ONLY the following keys:
{
  "intents": ["<intent>"],
  "entities": {
    "product_name": "<name or null>",
    "color": "<color or null>",
    "price_threshold": <number or null>,
    "price_condition": "<below/above/exact or null>",
    "category": "<category or null>",
    "tags": ["<tag>"]
  },
  "normalized_query": "<translated_query>",
  "requires_llm_answer": <boolean>
}
"""

class IntentRouter:

    async def detect(
        self,
        message,
        context_state=None,
        model_key="gemini-3.1-flash-lite-preview"
    ):

        prompt = f"{INTENT_PROMPT}\n"
        
        if context_state:
            prompt += f"\nCurrent Conversation State:\n{context_state}\n"
            
        prompt += f"\nUser Message:\n{message}"

        result = await provider_router.generate(
            model_key,
            prompt
        )

        parsed_json = None
        try:
            start = result.find('{')
            end = result.rfind('}') + 1
            if start != -1 and end != 0:
                parsed_json = json.loads(result[start:end])
        except Exception:
            pass

        if parsed_json:
            extracted_intents = parsed_json.get("intents", [])
            valid_extracted_intents = [
                i for i in extracted_intents if i in VALID_INTENTS
            ]
            
            if not valid_extracted_intents:
                valid_extracted_intents = ["fallback"]
                
            parsed_json["intents"] = valid_extracted_intents
            return parsed_json

        return {
            "intents": ["fallback"],
            "entities": {"product_name": message},
            "normalized_query": message,
            "requires_llm_answer": False
        }

intent_router = IntentRouter()
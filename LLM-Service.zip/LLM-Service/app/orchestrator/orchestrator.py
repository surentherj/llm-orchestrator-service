from app.orchestrator.intent_router import (
    intent_router
)

from app.services.memory.session_store import (
    session_store
)

from app.services.actions.cart_actions import (
    add_to_cart
)

from app.services.retrieval.hybrid_search import (
    hybrid_search
)

from app.services.llm.provider_router import (
    provider_router
)
import json

class Orchestrator:

    async def handle(
        self,
        conversation_id,
        message,
        model_key="gemini-3.1-flash-lite-preview"
    ):

        # Context merge
        session = await session_store.get(
            conversation_id
        )
        print( "=>", session)
        # Ultra-lightweight deterministic state tracking
        context_state = session.get("context_state", {})
        context_state_str = json.dumps(context_state) if context_state else ""

        # Intent detection
        intent_data = await intent_router.detect(
            message,
            context_state=context_state_str,
            model_key=model_key
        )
        
        intents = intent_data.get("intents", [])
        entities = intent_data.get("entities", {})
        query = intent_data.get("normalized_query", message)
        
        # Scenario 6: Context-based override ("add this")
        if "add_to_cart" in intents and not entities.get("product_name"):
            last_product = session.get("last_product")
            if last_product:
                if not entities.get("product_name"):
                    entities["product_name"] = last_product

        response_payload = {"intents": intents}
        results = None

        # DB / Cache / Vector phase
        if "product_query" in intents or "explain" in intents or ("add_to_cart" in intents and entities.get("price_threshold")):
            strict_filter = not ("add_to_cart" in intents and entities.get("price_threshold"))
            results = await hybrid_search.search(query, entities, strict_price_filter=strict_filter)
            response_payload["results"] = results
            
            if results:
                # Store the context for next queries
                session["last_product"] = results[0]["title"]

        # Action phase (Scenario 1, Scenario 5, Scenario 6)
        if "add_to_cart" in intents:
            can_add = True
            
            if results is not None:
                if len(results) == 0:
                    can_add = False
                    response_payload["reply"] = "Could not find a product matching those conditions to add."
                else:
                    # Scenario 5 Condition check
                    top_item = results[0]
                    price_threshold = entities.get("price_threshold")
                    price_condition = entities.get("price_condition")
                    
                    if price_threshold:
                        price = top_item["price"]
                        condition_failed = False
                        if price_condition == "below" and price >= price_threshold:
                            condition_failed = True
                        elif price_condition == "above" and price <= price_threshold:
                            condition_failed = True
                        elif price_condition == "exact" and price != price_threshold:
                            condition_failed = True
                            
                        if condition_failed:
                            can_add = False
                            response_payload["reply"] = f"Found {top_item['title']} for ₹{price}, which does not meet your condition to add."
                    
                    if can_add:
                        entities["product_name"] = top_item["title"]

            if can_add:
                if not entities.get("product_name"):
                    can_add = False
                    response_payload["reply"] = "I don't know what you want to add to your cart. Please specify a product."
                
                if can_add:
                    updated_intent = {"product_name": entities.get("product_name")}
                    action_resp = await add_to_cart(session, updated_intent)
                    response_payload["cart"] = action_resp["cart"]
                    if "reply" not in response_payload:
                        response_payload["reply"] = f"Added {entities.get('product_name')} to your cart!"

        # Handling Other Finite Intents
        elif "greeting" in intents:
            response_payload["reply"] = "Hello! Welcome to our store. How can I help you today?"

        elif "view_cart" in intents:
            cart = session.get("cart", [])
            if cart:
                response_payload["reply"] = f"You have these items in your cart: {', '.join(cart)}"
            else:
                response_payload["reply"] = "Your cart is currently empty."
                
        elif "place_order" in intents:
            cart = session.get("cart", [])
            if cart:
                import uuid
                order_id = str(uuid.uuid4())[:8]
                new_order = {
                    "order_id": order_id,
                    "items": list(cart),
                    "status": "pending shipment"
                }
                orders = session.get("orders", [])
                orders.append(new_order)
                session["orders"] = orders
                
                response_payload["reply"] = f"Order {order_id} Confirmed! Your items ({', '.join(cart)}) have been ordered."
                session["cart"] = [] # Clear the cart
            else:
                response_payload["reply"] = "You cannot place an order because your cart is empty."
                
        elif "order_status" in intents:
            orders = session.get("orders", [])
            if orders:
                recent_order = orders[-1]
                response_payload["reply"] = f"Your most recent order ({recent_order['order_id']}) is currently {recent_order['status']}."
            else:
                response_payload["reply"] = "You don't have any active orders."
            
        elif "order_history" in intents:
            orders = session.get("orders", [])
            if orders:
                history = [f"Order {o['order_id']}: {', '.join(o['items'])} ({o['status']})" for o in orders]
                response_payload["reply"] = "Your past orders:\n" + "\n".join(history)
            else:
                response_payload["reply"] = "You do not have any past orders yet."

        elif "fallback" in intents and "reply" not in response_payload:
            needs_llm = True
            
        # Final Response Builder / Generator (Scenario 4 or Fallback)
        needs_llm = "explain" in intents or (intent_data.get("requires_llm_answer") and "reply" not in response_payload) or ("fallback" in intents and "reply" not in response_payload)
        
        if needs_llm:
            prompt = f"State Context:\n{context_state_str}\n\nUser asked: {message}\nInformation we found: {results}\nAnswer naturally in a friendly manner. If you don't know, apologize politely."
            llm_reply = await provider_router.generate(model_key, prompt)
            response_payload["reply"] = llm_reply

        elif "reply" not in response_payload:
            # Deterministic fallbacks (Scenario 2, Scenario 3, Scenario 7)
            if results:
                top = results[0]
                response_payload["reply"] = f"Found {top['title']} for ₹{top['price']}!"
            else:
                response_payload["reply"] = "I couldn't find what you are looking for."

        # Keep a barebones Context State to minimize tokens for the next Intent call
        # No extra LLM summarization call required
        session["context_state"] = {
            "last_intent": intents[0] if intents else "fallback",
            "last_product_mentioned": entities.get("product_name") or session.get("last_product", ""),
            "last_ai_reply": response_payload.get("reply", "")
        }

        await session_store.set(
            conversation_id,
            session
        )

        return response_payload

orchestrator = Orchestrator()
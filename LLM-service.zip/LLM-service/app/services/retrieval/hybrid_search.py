DUMMY_DB = [
    {"id": 1, "title": "Blue Silk Saree", "price": 2000, "color": "blue", "tags": ["silk", "traditional", "wedding"]},
    {"id": 2, "title": "Green Wedding Saree", "price": 800, "color": "green", "tags": ["wedding", "cheap", "bridal"]},
    {"id": 3, "title": "Trending Red Saree", "price": 950, "color": "red", "tags": ["trending", "lit", "party"]}
]

class HybridSearch:

    async def search(
        self,
        query: str,
        entities: dict = None,
        strict_price_filter: bool = True
    ):
        if entities is None:
            entities = {}

        color = entities.get("color")
        price_threshold = entities.get("price_threshold")
        price_condition = entities.get("price_condition")
        
        results = []
        for item in DUMMY_DB:
            score = 0.0
            
            # Attribute filter
            if color and color.lower() == item["color"]:
                score += 0.3
            
            if price_threshold and strict_price_filter:
                if price_condition == "below" and item["price"] >= price_threshold:
                    continue
                if price_condition == "above" and item["price"] <= price_threshold:
                    continue
                if price_condition == "exact" and item["price"] != price_threshold:
                    continue

            # Tag Match
            tags = entities.get("tags", [])
            if tags and any(tag.lower() in item["tags"] for tag in tags):
                score += 0.2

            # Fuzzy / Semantic simulated: keyword overlapping
            query_parts = set(query.lower().split())
            item_parts = set(item["title"].lower().split() + item["tags"])
            overlap = len(query_parts.intersection(item_parts))
            
            if overlap > 0:
                # 0.4 semantic + 0.1 fuzzy = 0.5 total weight
                score += 0.5 * (overlap / len(query_parts))

            if score > 0 or not entities:
                item_copy = item.copy()
                item_copy["score"] = score
                results.append(item_copy)

        results.sort(key=lambda x: x["score"], reverse=True)
        return results

hybrid_search = HybridSearch()
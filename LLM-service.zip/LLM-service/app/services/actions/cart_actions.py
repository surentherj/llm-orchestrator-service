async def add_to_cart(
    session,
    intent_data
):

    cart = session.get(
        "cart",
        []
    )

    product = intent_data.get(
        "product_name"
    )

    cart.append(product)

    session["cart"] = cart

    return {
        "message": "Added to cart",
        "cart": cart
    }
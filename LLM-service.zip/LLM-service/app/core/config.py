import os
from dotenv import load_dotenv

load_dotenv()


class Settings:

    POSTGRES_URL = os.getenv("POSTGRES_URL")

    REDIS_URL = os.getenv("REDIS_URL")

    DEFAULT_MODEL = "gpt-4o-mini"

    DEFAULT_EMBEDDING = "text-embedding-3-small"


settings = Settings()
import json
from app.services.llm.provider_router import (
    provider_router
)

VALID_INTENTS = [
    "product_query", 
    "add_to_cart", 
    "view_cart", 
    "place_order", 
    "order_status", 
    "order_history", 
    "greeting", 
    "explain", 
    "fallback"
]

INTENT_PROMPT = """
# E-Commerce Intent & Context Engine

## Role
You are an intelligent routing agent. Your job is to classify the user's intent to select the correct downstream tool, and extract any relevant entities.

## Intents (Tool Selection)
Select 1 or more:
- product_query: searching products, checking price, catalog questions
- add_to_cart: explicit request to add an item
- view_cart: view cart items
- place_order: checkout and purchase
- order_status: track an existing order
- order_history: view past orders
- greeting: conversational openings ("hi", "hello")
- explain: qualitative info, FAQ, reviews, comparisons, or attribute questions (e.g. "what other colors?")
- fallback: unclear request or outside commerce scope

## Context & Memory Handling
You receive the `Current Conversation State`. Use it to resolve implicit references seamlessly:
1. **Implicit Coreference**: If the user uses pronouns ("add IT", "buy THAT") OR asks a follow-up about attributes (e.g., "what other colors?", "what size?") OR requests a repeat (e.g., "order the SAME", "buy AGAIN"), ALWAYS carry over `last_product_mentioned` as the `product_name`.
2. **Answering AI**: If the user is directly answering a question asked in `last_ai_reply` (e.g., they just say "blue" or "yes"), inherit the relevant intent and product context, updating only the new entities.
3. **Context Shifts**: If the user explicitly mentions a new topic or item (e.g., "now show me shoes"), IGNORE the previous context entirely. DO NOT blindly copy old products into new queries.
4. **No Invention**: If the user makes a generic statement (e.g., "hello", "view my cart", "checkout"), do not force a `product_name`. Set it to null.

## JSON Output Format
Return ONLY valid JSON (no markdown):
{
  "intents": ["str"],
  "entities": {
    "product_name": "str|null",
    "color": "str|null",
    "price_threshold": number|null,
    "price_condition": "below|above|exact|null",
    "category": "str|null",
    "tags": ["str"]
  },
  "normalized_query": "str",
  "requires_llm_answer": boolean
}
"""

class IntentRouter:

    async def detect(
        self,
        message,
        context_state=None,
        model_key="gemini-3.1-flash-lite-preview"
    ):

        prompt = f"{INTENT_PROMPT}\n"
        
        if context_state:
            prompt += f"\nCurrent Conversation State:\n{context_state}\n"
            
        prompt += f"\nUser Message:\n{message}"

        result = await provider_router.generate(
            model_key,
            prompt
        )

        parsed_json = None
        try:
            start = result.find('{')
            end = result.rfind('}') + 1
            if start != -1 and end != 0:
                parsed_json = json.loads(result[start:end])
        except Exception:
            pass

        if parsed_json:
            extracted_intents = parsed_json.get("intents", [])
            valid_extracted_intents = [
                i for i in extracted_intents if i in VALID_INTENTS
            ]
            
            if not valid_extracted_intents:
                valid_extracted_intents = ["fallback"]
                
            parsed_json["intents"] = valid_extracted_intents
            return parsed_json

        return {
            "intents": ["fallback"],
            "entities": {"product_name": message},
            "normalized_query": message,
            "requires_llm_answer": False
        }

intent_router = IntentRouter()